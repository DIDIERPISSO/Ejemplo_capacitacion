module.exports = {
  CUSTOMER_ID: '',
  USERNAME: '',
  PASSWORD: ''
}
